package com.example.hi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun Double.format(digits: Int) = "%.${digits}f".format(this)
    fun toastMe (view: View){
        val input: Editable? = editTextTextPersonName.text
        if (input == null) {
            Toast.makeText(this, "Вы не ввели мои деньги", Toast.LENGTH_LONG).show()
        } else {
            val fol: String = input.toString()
            if (switch1.isChecked) {
                textView3.text = ((fol.toDouble() * 74).format(2))
            } else textView3.text = ((fol.toDouble() / 74).format(2))
        }
    }

   /* fun convert () {
        val input: Editable? = editTextTextPersonName.text
        if (input == null) {
            Toast.makeText(this, "Вы не ввели мои деньги", Toast.LENGTH_LONG).show()
        } else {
            val fol: String = input.toString()
            if (switch1.isChecked) {
                textView3.text = (fol.toDouble() * 74).toString()
            } else textView3.text = (fol.toDouble() / 74).toString()
        }
    }*/
}
